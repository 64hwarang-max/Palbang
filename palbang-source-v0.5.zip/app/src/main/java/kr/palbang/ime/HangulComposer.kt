package kr.palbang.ime

class HangulComposer(private val emit:(String)->Unit, private val composing:(String)->Unit) {
 private val Ls=listOf('ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ')
 private val Vs=listOf('ㅏ','ㅐ','ㅑ','ㅒ','ㅓ','ㅔ','ㅕ','ㅖ','ㅗ','ㅘ','ㅙ','ㅚ','ㅛ','ㅜ','ㅝ','ㅞ','ㅟ','ㅠ','ㅡ','ㅢ','ㅣ')
 private val Ts=listOf('\u0000','ㄱ','ㄲ','ㄳ','ㄴ','ㄵ','ㄶ','ㄷ','ㄹ','ㄺ','ㄻ','ㄼ','ㄽ','ㄾ','ㄿ','ㅀ','ㅁ','ㅂ','ㅄ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ')
 private var l:Char?=null; private var v:Char?=null; private var t:Char?=null
 private val finalOK=Ts.drop(1).toSet()
 private val split=mapOf('ㄳ' to ('ㄱ' to 'ㅅ'),'ㄵ' to ('ㄴ' to 'ㅈ'),'ㄶ' to ('ㄴ' to 'ㅎ'),'ㄺ' to ('ㄹ' to 'ㄱ'),'ㄻ' to ('ㄹ' to 'ㅁ'),'ㄼ' to ('ㄹ' to 'ㅂ'),'ㄽ' to ('ㄹ' to 'ㅅ'),'ㄾ' to ('ㄹ' to 'ㅌ'),'ㄿ' to ('ㄹ' to 'ㅍ'),'ㅀ' to ('ㄹ' to 'ㅎ'),'ㅄ' to ('ㅂ' to 'ㅅ'))
 private val join=mapOf("ㄱㅅ" to 'ㄳ',"ㄴㅈ" to 'ㄵ',"ㄴㅎ" to 'ㄶ',"ㄹㄱ" to 'ㄺ',"ㄹㅁ" to 'ㄻ',"ㄹㅂ" to 'ㄼ',"ㄹㅅ" to 'ㄽ',"ㄹㅌ" to 'ㄾ',"ㄹㅍ" to 'ㄿ',"ㄹㅎ" to 'ㅀ',"ㅂㅅ" to 'ㅄ')
 private fun rendered():String { if(l==null) return ""; if(v==null) return l.toString(); val li=Ls.indexOf(l); val vi=Vs.indexOf(v); val ti=if(t==null)0 else Ts.indexOf(t); return if(li>=0&&vi>=0&&ti>=0) (0xAC00+(li*21+vi)*28+ti).toChar().toString() else "${l}${v}${t?:""}" }
 private fun show()=composing(rendered())
 fun consonant(c:Char){
  if(l==null){ l=c; show(); return }
  if(v==null){ commit(); l=c; show(); return }
  if(t==null && c in finalOK){ t=c; show(); return }
  if(t!=null){ val j=join["$t$c"]; if(j!=null){t=j;show();return} }
  commit(); l=c; show()
 }
 fun vowel(x:Char){
  if(l==null){ emit(x.toString()); return }
  if(v==null){ v=x; show(); return }
  if(t!=null){ val old=t!!; val sp=split[old]; if(sp!=null){t=sp.first; commit(); l=sp.second;v=x;t=null;show()} else {t=null; commit(); l=old;v=x;show()}; return }
  commit(); emit(x.toString())
 }
 fun commit(){ val s=rendered(); if(s.isNotEmpty()) emit(s); l=null;v=null;t=null;composing("") }
 fun backspace():Boolean { when { t!=null->t=null; v!=null->v=null; l!=null->l=null; else->return false }; show(); return true }
}
