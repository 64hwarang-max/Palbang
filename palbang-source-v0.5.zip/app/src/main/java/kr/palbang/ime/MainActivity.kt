package kr.palbang.ime

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity: Activity() {
 override fun onCreate(b: Bundle?) { super.onCreate(b)
  val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(48,60,48,30); gravity=Gravity.CENTER_HORIZONTAL }
  fun t(s:String, size:Float)=TextView(this).apply { text=s; textSize=size; setPadding(0,12,0,18) }
  box.addView(t("팔방 2026",28f)); box.addView(t("팔방미글의 8방향 모음 제스처를 최신 Android IME로 다시 구현한 시험판입니다.",17f))
  box.addView(Button(this).apply { text="1. 키보드 활성화"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } })
  box.addView(Button(this).apply { text="2. 팔방 2026 선택"; setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } })
  box.addView(t("제스처: →ㅏ  ←ㅓ  ↑ㅗ  ↓ㅜ  ↘ㅑ  ↖ㅕ  ↗ㅛ  ↙ㅠ\n복합모음: ↑→ㅘ, ↑→↓ㅙ, ↑↓ㅚ, ↓←ㅝ, ↓←↑ㅞ, ↓↑ㅟ\n\n물리/블루투스 키 입력은 가로채지 않도록 설계했습니다.",16f))
  setContentView(ScrollView(this).apply { addView(box) })
 }
}
