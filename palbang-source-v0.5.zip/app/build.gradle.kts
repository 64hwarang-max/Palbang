plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "kr.palbang.ime"; compileSdk = 36
    defaultConfig { applicationId = "kr.palbang.ime"; minSdk = 26; targetSdk = 36; versionCode = 5; versionName = "0.5.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
