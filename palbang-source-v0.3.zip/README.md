# 팔방 2026 prototype v0.2

팔방 제스처 입력을 최신 Android IME로 재구현한 시험판입니다.

## v0.2
- 한글 팔방 8방향 모음 제스처
- 한글 조합
- 한/영 전환: 영문 QWERTY 자판
- 123 전환: 숫자/기호 자판
- Shift, Backspace, Space, Enter
- 물리/블루투스 키 이벤트를 IME에서 임의 소비하지 않도록 설계
- Android 16 / API 36 target
- GitHub Actions APK 자동 빌드

## 주의
실기기 테스트 전 프로토타입입니다. 블루투스 키보드 공존은 실제 Galaxy 기기에서 키보드 설정(물리 키보드 연결 시 화면 키보드 표시 여부 포함)을 바꿔가며 검증해야 합니다.
