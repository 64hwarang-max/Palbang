package kr.palbang.ime

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.KeyEvent

class PalbangImeService:InputMethodService(), PalbangKeyboardView.Listener {
 private lateinit var composer:HangulComposer
 override fun onCreateInputView():View { composer=HangulComposer({ currentInputConnection.commitText(it,1) },{ currentInputConnection.setComposingText(it,1) }); return PalbangKeyboardView(this,this).apply { minimumHeight=(260*resources.displayMetrics.density).toInt() } }
 override fun onConsonant(c:Char)=composer.consonant(c)
 override fun onVowel(v:Char)=composer.vowel(v)
 override fun onText(s:String){ composer.commit(); currentInputConnection.commitText(s,1) }
 override fun onCommand(s:String){ when(s){
  "⌫"->{if(!composer.backspace()) currentInputConnection.deleteSurroundingText(1,0)}
  "SPACE"->{composer.commit();currentInputConnection.commitText(" ",1)}
  "ENTER"->{composer.commit();currentInputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_ENTER));currentInputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_ENTER))}
  "LANG","NUM","KO"->composer.commit()
 } }
 // 물리/블루투스 키보드 이벤트는 소비하지 않고 표준 입력 경로로 전달한다.
 override fun onKeyDown(keyCode:Int,event:KeyEvent):Boolean = super.onKeyDown(keyCode,event)
 override fun onKeyUp(keyCode:Int,event:KeyEvent):Boolean = super.onKeyUp(keyCode,event)
 override fun onFinishInput(){ if(::composer.isInitialized)composer.commit();super.onFinishInput() }
}
