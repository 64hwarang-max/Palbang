package kr.palbang.ime

import android.content.Context
import android.graphics.*
import android.view.*
import kotlin.math.*

class PalbangKeyboardView(ctx: Context, val listener: Listener) : View(ctx) {
    interface Listener { fun onConsonant(c: Char); fun onVowel(v: Char); fun onText(s: String); fun onCommand(s: String) }
    enum class Mode { KO, EN, NUM }
    var mode = Mode.KO; private set
    private val koRows = listOf(listOf("ㄱ","ㄴ","ㄷ","ㄹ","ㅁ"), listOf("ㅂ","ㅅ","ㅇ","ㅈ","ㅎ"), listOf("ㅋ","ㅌ","ㅍ","ㅊ","⌫"))
    private val enRows = listOf(listOf("q","w","e","r","t","y","u","i","o","p"), listOf("a","s","d","f","g","h","j","k","l"), listOf("⇧","z","x","c","v","b","n","m","⌫"))
    private val numRows = listOf(listOf("1","2","3","4","5","6","7","8","9","0"), listOf("@","#","₩","%","&","-","+","(",")"), listOf("*","\"","'",":",";","!","?","/","⌫"))
    private val p = Paint(1).apply { textAlign=Paint.Align.CENTER; typeface=Typeface.DEFAULT_BOLD }
    private var sx=0f; private var sy=0f; private var key=""; private val path=mutableListOf<Pair<Float,Float>>(); private var shift=false

    fun toggleLanguage(){ mode = if(mode==Mode.KO) Mode.EN else Mode.KO; invalidate() }
    fun toggleNumbers(){ mode = if(mode==Mode.NUM) Mode.KO else Mode.NUM; invalidate() }
    override fun onDraw(c: Canvas){
        super.onDraw(c); c.drawColor(Color.rgb(238,238,242)); val h=height/4f
        val rows = when(mode){ Mode.KO->koRows; Mode.EN->enRows; Mode.NUM->numRows }
        var y=0f
        rows.forEach { row -> var x=0f; val w=width/row.size.toFloat(); row.forEach { raw ->
            val s=if(mode==Mode.EN && shift && raw.length==1) raw.uppercase() else raw
            p.style=Paint.Style.FILL; p.color=Color.WHITE; c.drawRoundRect(x+4,y+5,x+w-4,y+h-5,12f,12f,p)
            p.color=Color.DKGRAY; p.textSize=if(row.size>=9) h*.22f else h*.30f; c.drawText(s,x+w/2,y+h*.58f,p); x+=w
        }; y+=h }
        val bottom=listOf(if(mode==Mode.NUM) "한글" else "123", if(mode==Mode.EN) "영/한" else "한/영", "SPACE", "ENTER")
        val widths=listOf(width*.16f,width*.20f,width*.40f,width*.24f); var x=0f
        bottom.forEachIndexed { i,s -> val w=widths[i]; p.color=Color.WHITE;c.drawRoundRect(x+5,y+5,x+w-5,y+h-5,12f,12f,p);p.color=Color.DKGRAY;p.textSize=h*.18f;c.drawText(s,x+w/2,y+h*.58f,p);x+=w }
    }
    private fun currentRows()=when(mode){Mode.KO->koRows;Mode.EN->enRows;Mode.NUM->numRows}
    private fun hit(x:Float,y:Float):String{
        val ri=(y/(height/4f)).toInt().coerceIn(0,3)
        if(ri<3){ val row=currentRows()[ri]; return row[(x/(width/row.size.toFloat())).toInt().coerceIn(0,row.lastIndex)] }
        val row=listOf(if(mode==Mode.NUM) "한글" else "123",if(mode==Mode.EN) "영/한" else "한/영","SPACE","ENTER")
        val cuts=floatArrayOf(.16f,.36f,.76f,1f); val f=x/width; return row[cuts.indexOfFirst{f<=it}.coerceAtLeast(0)]
    }
    override fun onTouchEvent(e:MotionEvent):Boolean { when(e.actionMasked){
        MotionEvent.ACTION_DOWN->{sx=e.x;sy=e.y;key=hit(e.x,e.y);path.clear();path.add(e.x to e.y);return true}
        MotionEvent.ACTION_MOVE->{path.add(e.x to e.y);return true}
        MotionEvent.ACTION_UP->{path.add(e.x to e.y); handleKey(); return true}
    };return true }
    private fun handleKey(){
        if(mode==Mode.KO && key.length==1 && "ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅎㅋㅌㅍㅊ".contains(key)){
            val vowel=vowelFor(dirs(path)); listener.onConsonant(key[0]); if(vowel!=null) listener.onVowel(vowel); return
        }
        when(key){
            "⌫","SPACE","ENTER"->listener.onCommand(key)
            "한/영","영/한"->{listener.onCommand("LANG");toggleLanguage()}
            "123"->{listener.onCommand("NUM");mode=Mode.NUM;invalidate()}
            "한글"->{listener.onCommand("KO");mode=Mode.KO;invalidate()}
            "⇧"->{shift=!shift;invalidate()}
            else->{ var s=key; if(mode==Mode.EN && shift) s=s.uppercase(); listener.onText(s); if(mode==Mode.EN && shift){shift=false;invalidate()} }
        }
    }
    private fun dirs(ps:List<Pair<Float,Float>>):List<Int>{ val threshold=28*resources.displayMetrics.density; val out=mutableListOf<Int>(); var ax=sx;var ay=sy
        for((x,y) in ps){val dx=x-ax;val dy=y-ay;if(hypot(dx,dy)<threshold)continue;val a=Math.toDegrees(atan2((-dy).toDouble(),dx.toDouble()));val d=when{a>=-22.5&&a<22.5->0;a>=22.5&&a<67.5->1;a>=67.5&&a<112.5->2;a>=112.5&&a<157.5->3;a>=157.5||a< -157.5->4;a>=-157.5&&a< -112.5->5;a>=-112.5&&a< -67.5->6;else->7};if(out.lastOrNull()!=d)out.add(d);ax=x;ay=y};return out }
    private fun vowelFor(d:List<Int>):Char? { if(d.isEmpty())return null; val s=d.joinToString(","); val complex=mapOf("2,0" to 'ㅘ',"2,0,6" to 'ㅙ',"2,6" to 'ㅚ',"6,4" to 'ㅝ',"6,4,2" to 'ㅞ',"6,2" to 'ㅟ',"0,6" to 'ㅐ',"0,2" to 'ㅐ',"4,6" to 'ㅔ',"4,2" to 'ㅔ',"7,6" to 'ㅒ',"7,2" to 'ㅒ',"3,6" to 'ㅖ',"3,2" to 'ㅖ'); complex[s]?.let{return it}; if(d.size>=2&&(d[0]==0||d[0]==4)&&(d[1]==2||d[1]==6))return 'ㅢ'; return when(d[0]){0->'ㅏ';4->'ㅓ';2->'ㅗ';6->'ㅜ';7->'ㅑ';3->'ㅕ';1->'ㅛ';5->'ㅠ';else->null} }
}
