plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "kr.palbang.ime"; compileSdk = 36
    defaultConfig { applicationId = "kr.palbang.ime"; minSdk = 26; targetSdk = 36; versionCode = 3; versionName = "0.3.0" }
}
